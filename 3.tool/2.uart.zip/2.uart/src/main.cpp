
#include "main.h"

Files        file("/home/bien/Desktop/gpio_blynk.bin", std::ios::in|std::ios::binary);
//Files        file("/home/bien/Desktop/bien.txt", std::ios::in|std::ios::binary);
SerialPort   serial("/dev/ttyUSB0", 9600, 1);
DebugLogger  debugLog;
GetMessage   getmessage;
FrameMessage framemessage;

void CreateMessageUpdateDeviceTest(void);
int main()
{
  //std::cout << "UART Starts" << std::endl;
  uint8_t array[200];
  uint8_t array2[200];
  uint16_t sizeof_message = 0;
  uint16_t sizeofw = 0;

  CreateMessageUpdateDeviceTest();
  /*
  while (1)
  {
    int32_t checkdata = serial.Available();
    if (checkdata > 0)
    {
      getmessage.GetMessages(serial.readbyte(), array);
      if (getmessage.IsMessage(sizeof_message) == 1)
      {
        if (sizeof_message > 0)
        {
          messageFrameMsg_t dataout;
          printf("\n-(Size    : %d)-\n", framemessage.DetectMessage(array, &dataout));
          printf("Start     : %x\n", dataout.Start);
          printf("TypeMSG   : %x\n", dataout.TypeMessage);
          printf("Length    : %d\n", dataout.Length);
          printf("Value     : ");
          for (int i = 0; i < dataout.Length - DEFAULT_BYTE_CHECKSUM; i++)
          {
            printf("%d ", dataout.Data[i]);
          }
          printf("\nCheck sum : %x\n", dataout.Crc);
        }
      }
    }
    
    usleep(1000);
    getmessage.TimeOut();
  }
  */
  return 0;
}

void CreateMessageUpdateDeviceTest(void)
{
	uint8_t arr2[200], sizearr = 0;
  uint8_t length_send = 0;
  uint32_t size_file_bin = 0;
  uint32_t offset_bin = 0, size_get_bin = 128;
	uploadMetaData_t *meta_data, meta_data_temp;
	
	uploadDeleteFile_t *deletes, delete_temp;
	size_file_bin = file.Files_GetSizeFile();

  printf("Size File: %d\n", size_file_bin);

	printf("\n---------------(Create Message Metadata Test)---------------\n");
	meta_data_temp.cmd          = OTA_STATE_START;
	meta_data_temp.package_crc  = 0xAABBCCDD;
	meta_data_temp.package_size = file.Files_GetSizeFile();
	memcpy(meta_data_temp.name, "gpio_bien.bin", sizeof("gpio_bien.bin"));
	meta_data = &meta_data_temp;
	sizearr = framemessage.CreateMessage(TYPE_MSG_UPDATE_FILE,9+sizeof("gpio_bien.bin"),(uint8_t*)meta_data, arr2);
	for(int i=0; i<sizearr; i++)
	{
		if (arr2[i] <= 0x0f)
    {
      printf("0%x ", arr2[i]);
    }
    else
    {
      printf("%x ", arr2[i]);
    }
	}
  serial.writebyte(arr2, sizearr);
  length_send = (size_file_bin/128)+1;
  printf("\ncount: %d\n", length_send);
  sleep(5);
  for(int i=0; i<length_send; i++)
  {
    uint32_t sizedata = 0;
    uploadData_t *data, data_temp;
    if((size_file_bin-offset_bin)>128)
    {
      
      data_temp.cmd = OTA_STATE_DATA;
      data_temp.length  = 128;
      data_temp.offset  = offset_bin;
      sizedata =  file.Files_GetArrFile(128, offset_bin, data_temp.data);
      data = &data_temp;
      sizearr = framemessage.CreateMessage(TYPE_MSG_UPDATE_FILE,sizeof(uploadData_t), (uint8_t*)data, arr2);
      printf("sizearr: %d\n", sizearr);
    }
    else
    {
      data_temp.cmd = OTA_STATE_DATA;
      data_temp.length  = size_file_bin-offset_bin;
      data_temp.offset  = offset_bin;
      sizedata =  file.Files_GetArrFile(size_file_bin-offset_bin, offset_bin, data_temp.data);
      data = &data_temp;
      sizearr = framemessage.CreateMessage(TYPE_MSG_UPDATE_FILE,sizeof(uploadData_t), (uint8_t*)data, arr2);
      printf("sizearr: %d\n", sizearr);
    }
    serial.writebyte(arr2, sizearr);
    offset_bin += sizedata;
    sleep(1);
  }
  
  /*
  printf("\n---------------(Create Message data Test)---------------\n");
	data_temp.cmd = OTA_STATE_DATA;
	data_temp.length  = 128;
	data_temp.offset  = 0;
	// for(int i=0; i<128; i++)
	// {
	// 	data_temp.data[i] = i+1;
	// }
  file.Files_GetArrFile(128, 0, data_temp.data);
	data = &data_temp;
  sizearr = framemessage.CreateMessage(TYPE_MSG_UPDATE_FILE,sizeof(uploadData_t), (uint8_t*)data, arr2);
  printf("sizearr: %d\n", sizearr);
	for(int i=0; i<sizearr; i++)
	{
		if (arr2[i] <= 0x0f)
    {
      printf("0%x ", arr2[i]);
    }
    else
    {
      printf("%x ", arr2[i]);
    }
	}
  */
    

	printf("\n---------------(Done)---------------\n");
}