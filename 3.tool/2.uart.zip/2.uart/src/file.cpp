#include "file.h"

Files::Files(const char *name_file,  std::ios_base::openmode __mode)
{
    in_file.open(name_file, __mode);
    if (!in_file.is_open()) 
    {
		std::cerr << "Error in open file: " << name_file << std::endl;
	}
}

Files::~Files()
{
  in_file.close();
}

uint32_t Files::Files_GetSizeFile(void)
{
  in_file.seekg(0, std::ios::end);
  return in_file.tellg();
}

uint8_t Files::Files_GetArrFile(const uint16_t size, const uint16_t offset, uint8_t *arr)
{
    uint8_t data = 0, count_read_data = 0;
    if (!in_file.is_open() ) 
    {
		return 0;
	}
    in_file.seekg(offset);
    for(count_read_data = 0; count_read_data < size; count_read_data++)
    {
	    in_file.read((char*)&data, sizeof(uint8_t));
        arr[count_read_data] = data;
    }
    return count_read_data;
}
void Files::Files_Clear(void)
{
  in_file.close();
}