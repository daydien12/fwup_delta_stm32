#include "handle_msg.h"

void HandleMsg::Handle_UpdateFile(void)
{

}