#include "handle_msg.h"

uint8_t HandleMsg::Handle_UpdateFile(const char *name_file_bin, const char *port, const char *name_file)
{
  uint8_t arr[150], sizearr = 0;
  uint8_t length_send = 0;
  uint32_t size_file_bin = 0;
  uint32_t offset_bin = 0;

  SerialPort   uart(port, 9600, 1);
  Files files(name_file_bin, std::ios::in | std::ios::binary);
  size_file_bin = files.Files_GetSizeFile();
  files.Files_Clear();

  sizearr = UpdateFile_CreateFrameMetaData(name_file_bin, 0xAABBCCDD, name_file, arr);
  uart.writebyte(arr, sizearr);
  sleep(1);
  length_send = (size_file_bin / 128) + 1;
  for (int i = 0; i < length_send; i++)
  {
    if ((size_file_bin - offset_bin) > 128)
    {
      sizearr = UpdateFile_CreateFrameData(name_file_bin, 128, offset_bin, arr);
    }
    else
    {
      sizearr = UpdateFile_CreateFrameData(name_file_bin, (size_file_bin - offset_bin), offset_bin, arr);
    }
    uart.writebyte(arr, sizearr);
    offset_bin += sizearr - 12;
    sleep(1);
  }
  uart.~SerialPort();
  return 1;
}

uint32_t HandleMsg::UpdateFile_CreateFrameMetaData(const char *name_file_bin, const uint32_t package_crc , const char *name_file, uint8_t *dataout)
{
  uint8_t sizearr = 0, length_name = strlen(name_file) + 1;
  FrameMessage framemessage;
  Files file(name_file_bin, std::ios::in | std::ios::binary);
  uploadMetaData_t *meta_data, meta_data_temp;
  meta_data_temp.cmd          = OTA_STATE_START;
  meta_data_temp.package_crc  = package_crc;
  meta_data_temp.package_size = file.Files_GetSizeFile();
  printf("size %d\n", file.Files_GetSizeFile());
  memcpy(meta_data_temp.name, name_file, length_name);
  meta_data = &meta_data_temp;
  sizearr = framemessage.CreateMessage(TYPE_MSG_UPDATE_FILE, (9 + length_name), (uint8_t*)meta_data, dataout);
  file.Files_Clear();
  return sizearr;
}

uint32_t HandleMsg::UpdateFile_CreateFrameData(const char *name_file_bin, const uint32_t length, const uint32_t offset, uint8_t *dataout)
{
  uint8_t lengths = 0;
  FrameMessage framemessage;
  Files file(name_file_bin, std::ios::in | std::ios::binary);
  uploadData_t *data, data_temp;
  data_temp.cmd = OTA_STATE_DATA;
  data_temp.length  = length;
  data_temp.offset  = offset;
  file.Files_GetArrFile(length, offset, data_temp.data);
  data = &data_temp;
  lengths = framemessage.CreateMessage(TYPE_MSG_UPDATE_FILE, sizeof(uploadData_t) - (128 - length), (uint8_t*)data, dataout);
  printf("lenth: %d\n", lengths);
  file.Files_Clear();
  return lengths;
}