#include "handle_msg.h"
uint32_t UpdateFile_CreateFrameMetaData(const char *name_file_bin, const char *name_file, uint8_t *dataout, uint32_t &size_file);
uint32_t UpdateFile_CreateFrameData(const char *name_file_bin, const uint32_t length, const uint32_t offset, uint8_t *dataout);

uint32_t HandleMsg::Handle_UpdateFile(const char *name_file_bin, const char *port, const char *name_file, uint8_t &state,  uint32_t &offset, uint32_t &size_file_bin)
{
  uint8_t arr[150], size_arr = 0;
  uint32_t length_send = 0;

  SerialPort   uart(port, 9600, 1);
  switch (state)
  {
    case OTA_STATE_START:
      offset = 0;
      size_arr = UpdateFile_CreateFrameMetaData(name_file_bin, name_file, arr, size_file_bin);
      uart.writebyte(arr, size_arr);
      break;

    case OTA_STATE_DATA:
      if ((size_file_bin - offset) > LENGTH_SEND)
      {
        size_arr = UpdateFile_CreateFrameData(name_file_bin, LENGTH_SEND, offset, arr);
      }
      else
      {
        size_arr = UpdateFile_CreateFrameData(name_file_bin, (size_file_bin - offset), offset, arr);
      }
      uart.writebyte(arr, size_arr);
      offset += size_arr - 12;
     break;

    case OTA_STATE_END:
      
     break;
  

    default:
      break;
  }
  uart.~SerialPort();
  return 1;
}

uint32_t UpdateFile_CreateFrameMetaData(const char *name_file_bin, const char *name_file, uint8_t *dataout, uint32_t &size_file)
{
  uint8_t sizearr = 0, length_name = strlen(name_file) + 1;
  FrameMessage framemessage;
  Files file(name_file_bin, std::ios::in | std::ios::binary);
  uploadMetaData_t *meta_data, meta_data_temp;
  size_file = file.Files_GetSizeFile();
  meta_data_temp.cmd          = OTA_STATE_START;
  meta_data_temp.package_crc  = file.Files_CalculatorChecksum();
  meta_data_temp.package_size = size_file;
  printf("size %d\n", file.Files_GetSizeFile());
  memcpy(meta_data_temp.name, name_file, length_name);
  meta_data = &meta_data_temp;
  sizearr = framemessage.CreateMessage(TYPE_MSG_UPDATE_FILE, (9 + length_name), (uint8_t*)meta_data, dataout);
  file.Files_Clear();
  return sizearr;
}

uint32_t UpdateFile_CreateFrameData(const char *name_file_bin, const uint32_t length, const uint32_t offset, uint8_t *dataout)
{
  uint8_t lengths = 0;
  FrameMessage framemessage;
  Files file(name_file_bin, std::ios::in | std::ios::binary);
  uploadData_t *data, data_temp;
  data_temp.cmd = OTA_STATE_DATA;
  data_temp.length  = length;
  data_temp.offset  = offset;
  file.Files_GetArrFile(length, offset, data_temp.data);
  data = &data_temp;
  lengths = framemessage.CreateMessage(TYPE_MSG_UPDATE_FILE, sizeof(uploadData_t) - (128 - length), (uint8_t*)data, dataout);
  file.Files_Clear();
  return lengths;
}