/*
#include <stdio.h>
#include "janpatch.h"

static unsigned char source_buf[4096];
static unsigned char target_buf[4096];
static unsigned char patch_buf[4096];

typedef struct {
    uint8_t     *buffer;
    size_t      size;       
    long int    position;   
}Stream_t;


typedef enum {
    IMAGE_TYPE_LOADER = 0x1,
    IMAGE_TYPE_APP = 0x2,
    IMAGE_TYPE_UPDATER = 0x3,
} image_type_t;

typedef enum {
    IMAGE_SLOT_1 = 1,
    IMAGE_SLOT_2 = 2,
    IMAGE_NUM_SLOTS,
} image_slot_t;

typedef enum {
    IMAGE_VERSION_1 = 1,
    IMAGE_VERSION_2 = 2,
    IMAGE_VERSION_CURRENT = IMAGE_VERSION_2,
} image_version_t;

typedef enum {
    SFIO_STREAM_SLOT,
    SFIO_STREAM_RAM,
} sfio_stream_type_t;

typedef struct {
    sfio_stream_type_t type;
    size_t offset;
    size_t size;
    FILE* file;
} sfio_stream_t;

size_t sfio_fread(void *ptr, size_t size, size_t count, sfio_stream_t *stream);
size_t sfio_fwrite(const void *ptr, size_t size, size_t count, sfio_stream_t *stream);
int sfio_fseek(sfio_stream_t *stream, long int offset, int whence);

#define FILE_OLD "demo/blinky-k64f-old.bin"
#define FILE_PATCH "demo/blinky-k64f.patch"
#define FILE_CREATE "./blinky-k64f-patched.bin"

size_t sfio_fread(void* ptr, size_t size, size_t count, sfio_stream_t* stream) 
{
    size_t bytesToRead = size * count;

    // Kiểm tra xem còn đủ dữ liệu để đọc không
    if (stream->offset + bytesToRead > stream->size) 
    {
        bytesToRead = stream->size - stream->offset;
    }

    // Di chuyển con trỏ đọc đến vị trí mong muốn
    fseek(stream->file, stream->offset, SEEK_SET);

    // Đọc dữ liệu từ tệp tin
    size_t bytesRead = fread(ptr, 1, bytesToRead, stream->file);

    // Cập nhật vị trí đọc mới
    stream->offset += bytesRead;

    return bytesRead;
}

size_t sfio_fwrite(const void* ptr, size_t size, size_t count, sfio_stream_t* stream) 
{
    size_t bytesToWrite = size * count;

    // Kiểm tra xem còn đủ dung lượng để ghi không
    if (stream->offset + bytesToWrite > stream->size) 
    {
        bytesToWrite = stream->size - stream->offset;
    }

    // Di chuyển con trỏ ghi đến vị trí mong muốn
    fseek(stream->file, stream->offset, SEEK_SET);

    // Ghi dữ liệu vào tệp tin
    size_t bytesWritten = fwrite(ptr, 1, bytesToWrite, stream->file);

    // Cập nhật vị trí ghi mới
    stream->offset += bytesWritten;

    return bytesWritten;
}

int sfio_fseek(sfio_stream_t *stream, long int offset, int origin) {
  
    if (offset > stream->size) {
        return -1;
    } else {
        stream->offset = offset; 
    }
    return 0;
}


int main() {

    printf("%s \n", FILE_OLD);
    printf("%s \n", FILE_PATCH);
    printf("%s \n", FILE_CREATE);
    
    // // Open streams
    FILE *old = fopen(FILE_OLD, "rb");
    FILE *patch = fopen(FILE_PATCH, "rb");
    FILE *target =  fopen(FILE_CREATE, "wb");

    if (!old) {
        printf("Could not open '%s'\n", FILE_OLD);
        return 1;
    }
    if (!patch) {
        printf("Could not open '%s'\n", FILE_PATCH);
        return 1;
    }
    if (!target) {
        printf("Could not open '%s'\n", FILE_CREATE);
        return 1;
    }

    // // janpatch_ctx contains buffers, and references to the file system functions
    janpatch_ctx ctx = {
        { source_buf, 4096 },
        { target_buf, 4096 },
        { patch_buf , 4096  },

        &sfio_fread,
        &sfio_fwrite,
        &sfio_fseek,
        NULL
    };

     return janpatch(ctx, old, patch, target);
}


*/


#include <stdio.h>
#include "janpatch.h"

#define FILE_OLD "demo/blinky-k64f-old.bin"
#define FILE_PATCH "demo/blinky-k64f.patch"
#define FILE_CREATE "./blinky-k64f-patched.bin"


typedef struct {
    size_t offset;
    size_t size;
    FILE *file;
} sfio_stream_t;

size_t sfio_fread(void* ptr, size_t size, size_t count, sfio_stream_t* stream) 
{
    size_t bytesToRead = size * count;

    // Kiểm tra xem còn đủ dữ liệu để đọc không
    if (stream->offset + bytesToRead > stream->size) 
    {
        bytesToRead = stream->size - stream->offset;
    }

    // Di chuyển con trỏ đọc đến vị trí mong muốn
    fseek(stream->file, stream->offset, SEEK_SET);

    // Đọc dữ liệu từ tệp tin
    size_t bytesRead = fread(ptr, 1, bytesToRead, stream->file);

    // Cập nhật vị trí đọc mới
    stream->offset += bytesRead;

    return bytesRead;
}

long int findSize(char file_name[])
{
    // opening the file in read mode
    FILE* fp = fopen(file_name, "r");
  
    // checking if the file exist or not
    if (fp == NULL) {
        printf("File Not Found!\n");
        return -1;
    }
  
    fseek(fp, 0L, SEEK_END);
  
    // calculating the size of the file
    long int res = ftell(fp);
  
    // closing the file
    fclose(fp);
  
    return res;
}
  

int main() {
    sfio_stream_t source;
    printf("%s \n", FILE_OLD);
    printf("%s \n", FILE_PATCH);
    printf("%s \n", FILE_CREATE);
    // // Open streams
    FILE *old = fopen(FILE_OLD, "rb");
    FILE *patch = fopen(FILE_PATCH, "rb");
    FILE *target =  fopen(FILE_CREATE, "wb");

    printf("The size of the file is %ld bytes.\n", findSize(FILE_OLD));

    if (!old) {
        printf("Could not open '%s'\n", FILE_OLD);
        return 1;
    }

    if (!patch) {
        printf("Could not open '%s'\n", FILE_PATCH);
        return 1;
    }
    if (!target) {
        printf("Could not open '%s'\n", FILE_CREATE);
        return 1;
    }

    
    source.file   = old;
    source.offset = 0;
    source.size   =  findSize(FILE_OLD);

    // // janpatch_ctx contains buffers, and references to the file system functions
    janpatch_ctx ctx = {
        { (unsigned char*)malloc(1024), 1024 }, // source buffer
        { (unsigned char*)malloc(1024), 1024 }, // patch buffer
        { (unsigned char*)malloc(1024), 1024 }, // target buffer

        &sfio_fread,
        &fwrite,
        &fseek,
        &ftell
    };

     return janpatch(ctx, &source, patch, target);
}


